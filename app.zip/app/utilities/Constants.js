export const ANSWER_TYPE_SINGLE = 'Singlechoice';
export const ANSWER_TYPE_MULTIPLE = 'Multiplechoice';
export const ANSWER_TYPE_TEXT = 'Freetext';
